"""OpenStreetMap/Overpass discovery helpers for the Ilaro GIS-SDSS.

Discovered records are deliberately returned as *candidates* with
verification_status='unverified'. The application never presents OSM
discovery as field verification.
"""
import json
import urllib.parse
import urllib.request

ILARO_BBOX = (6.84, 2.94, 6.95, 3.08)  # south, west, north, east


def _category(tags):
    # Local names are useful in Ilaro because many small businesses are
    # mapped only as generic shops/amenities. These keyword rules improve
    # the research inventory without claiming that the name itself is a
    # formal classification.
    name = (tags.get("name") or "").lower()
    if any(k in name for k in ("playstation", "play station", "ps5", "ps4", "gaming centre", "gaming center")):
        return "PlayStation / Gaming Centre"
    if any(k in name for k in ("viewing centre", "viewing center", "football viewing")):
        return "Viewing Centre"
    if any(k in name for k in ("canteen", "buka", "food joint", "chop bar")):
        return "Canteen / Food Vendor"
    if any(k in name for k in ("shopping centre", "shopping center")):
        return "Shopping Centre"
    amenity = (tags.get("amenity") or "").lower()
    tourism = (tags.get("tourism") or "").lower()
    shop = (tags.get("shop") or "").lower()
    leisure = (tags.get("leisure") or "").lower()
    office = (tags.get("office") or "").lower()
    healthcare = (tags.get("healthcare") or "").lower()
    craft = (tags.get("craft") or "").lower()
    education = (tags.get("education") or "").lower()
    emergency = (tags.get("emergency") or "").lower()
    highway = (tags.get("highway") or "").lower()
    public_transport = (tags.get("public_transport") or "").lower()

    if tourism in {"hotel", "motel"}: return "Hotel"
    if tourism in {"guest_house", "hostel"}: return "Guest House"
    if tourism in {"apartment", "chalet"}: return "Short-let / Apartment"
    if tourism in {"resort", "camp_site"}: return "Hotel / Event Centre"

    if healthcare in {"hospital"} or amenity == "hospital": return "Hospital"
    if healthcare in {"clinic", "doctor", "health_centre"} or amenity in {"clinic", "doctors"}: return "Clinic"
    if healthcare == "dentist" or amenity == "dentist": return "Dental Clinic"
    if healthcare in {"laboratory", "diagnostic"}: return "Medical Laboratory"
    if amenity == "pharmacy": return "Pharmacy"
    if amenity == "police": return "Police / Security"
    if amenity == "fire_station" or emergency == "fire_hydrant": return "Fire Service"
    if amenity == "post_office": return "Post Office"
    if amenity == "bank": return "Bank"
    if amenity == "atm": return "ATM"
    if amenity == "restaurant": return "Restaurant"
    if amenity in {"fast_food", "food_court"}: return "Fast Food"
    if amenity == "cafe": return "Cafe / Coffee Shop"
    if amenity == "marketplace": return "Market"
    if amenity == "school" or education in {"school", "secondary"}: return "School"
    if amenity in {"college", "university"} or education in {"college", "university"}: return "University / Polytechnic"
    if amenity == "kindergarten" or education in {"kindergarten", "nursery"}: return "Nursery / Creche"
    if amenity == "place_of_worship":
        religion = (tags.get("religion") or "").lower()
        return "Mosque" if religion == "muslim" else ("Church" if religion == "christian" else "Religious Centre")
    if amenity == "community_centre": return "Community Centre"
    if amenity == "library": return "Library"
    if amenity == "courthouse": return "Court"
    if amenity in {"townhall", "government"} or office in {"government", "administrative"}: return "Government Office"
    if amenity == "fuel": return "Filling Station"
    if amenity == "bus_station": return "Motor Park"
    if amenity == "bus_stop" or highway == "bus_stop" or public_transport == "platform": return "Bus Stop"
    if amenity == "internet_cafe": return "Computer / ICT Centre"
    if amenity == "cinema": return "Entertainment Centre"
    if amenity in {"gaming", "video_games"}: return "PlayStation / Gaming Centre"
    if amenity == "sports_centre" or leisure in {"sports_centre", "pitch", "stadium", "fitness_centre"}: return "Sports / Recreation"
    if leisure == "playground": return "Sports / Recreation"
    if amenity in {"events_venue", "conference_centre"}: return "Event Centre"

    if shop in {"supermarket", "department_store"}: return "Supermarket"
    if shop == "mall": return "Shopping Mall"
    if shop in {"convenience", "general", "kiosk"}: return "Provision Store"
    if shop == "bakery": return "Bakery"
    if shop in {"clothes", "fashion"}: return "Boutique / Clothing"
    if shop in {"electronics", "computer"}: return "Electronics Shop"
    if shop in {"mobile_phone", "mobile_phone_accessories"}: return "Phone / Accessories Shop"
    if shop in {"hardware", "doityourself"}: return "Building Materials"
    if shop in {"car", "car_parts", "motorcycle", "tyres"}: return "Auto Parts"
    if shop in {"agricultural", "farm"}: return "Agro Service"
    if shop in {"video_games", "games"}: return "PlayStation / Gaming Centre"

    if craft in {"tailor", "dressmaker"}: return "Tailor / Fashion"
    if craft in {"car_repair", "mechanic"}: return "Mechanic Workshop"
    if craft == "car_wash": return "Car Wash"
    if craft == "laundry": return "Laundry"
    if craft in {"hairdresser", "beauty"}: return "Barbershop / Salon"

    return None


def discover_ilaro(timeout=45):
    s, w, n, e = ILARO_BBOX
    query = f"""
[out:json][timeout:40];
(
  nwr["name"]["amenity"]({s},{w},{n},{e});
  nwr["name"]["tourism"]({s},{w},{n},{e});
  nwr["name"]["shop"]({s},{w},{n},{e});
  nwr["name"]["leisure"]({s},{w},{n},{e});
  nwr["name"]["office"]({s},{w},{n},{e});
  nwr["name"]["healthcare"]({s},{w},{n},{e});
  nwr["name"]["craft"]({s},{w},{n},{e});
  nwr["name"]["education"]({s},{w},{n},{e});
  nwr["name"]["emergency"]({s},{w},{n},{e});
  nwr["name"]["public_transport"]({s},{w},{n},{e});
);
out center tags;
"""
    data = urllib.parse.urlencode({"data": query}).encode()
    req = urllib.request.Request(
        "https://overpass-api.de/api/interpreter",
        data=data,
        headers={"User-Agent": "GIS-SDSS-Ilaro/2.0 facility-discovery"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))

    results = []
    seen = set()
    for el in payload.get("elements", []):
        tags = el.get("tags") or {}
        name = (tags.get("name") or "").strip()
        category = _category(tags)
        if not name or not category:
            continue
        if el.get("type") == "node":
            lat, lon = el.get("lat"), el.get("lon")
        else:
            center = el.get("center") or {}
            lat, lon = center.get("lat"), center.get("lon")
        if lat is None or lon is None:
            continue
        key = (name.casefold(), category, round(float(lat), 5), round(float(lon), 5))
        if key in seen:
            continue
        seen.add(key)
        address_parts = [tags.get(k) for k in ("addr:housenumber", "addr:street", "addr:suburb", "addr:city") if tags.get(k)]
        results.append({
            "name": name,
            "facility_type": tags.get("amenity") or tags.get("shop") or tags.get("tourism") or tags.get("craft") or category,
            "facility_category": category,
            "address": ", ".join(address_parts) or "Ilaro, Yewa South, Ogun State, Nigeria",
            "phone": tags.get("phone") or tags.get("contact:phone") or "",
            "description": "OpenStreetMap facility candidate; requires local verification.",
            "latitude": float(lat),
            "longitude": float(lon),
            "data_source": "OpenStreetMap / Overpass",
            "verification_status": "unverified",
            "source_reference": f"https://www.openstreetmap.org/{el.get('type')}/{el.get('id')}",
            "capture_method": "OSM discovery",
            "website": tags.get("website") or tags.get("contact:website") or "",
            "opening_hours": tags.get("opening_hours") or "",
            "sub_category": tags.get("amenity") or tags.get("shop") or tags.get("tourism") or "",
            "operational_status": "unknown",
        })
    return sorted(results, key=lambda x: (x["facility_category"], x["name"].casefold()))
