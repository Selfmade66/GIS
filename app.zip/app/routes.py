import csv, io, os
from flask import Blueprint, current_app, jsonify, render_template, request, Response
from .db import (CATEGORIES, VERIFICATION, categories, delete, get, import_csv, nearby, rows, summary, write,
                  verification_summary, verification_history, mark_field_verified,
                  update_verification_status, mark_duplicate, possible_duplicates,
                  source_summary, locality_summary)
from .analysis import accessibility, mcda, scenario
from .osm import discover_ilaro

bp=Blueprint('main',__name__)

def page(template, **ctx): return render_template(template, **ctx)

@bp.get('/')
def home(): return page('index.html')
@bp.get('/dashboard')
def dashboard(): return page('dashboard.html')
@bp.get('/map')
def map_page(): return page('map.html')
@bp.get('/facilities')
def facilities_page(): return page('facilities.html')
@bp.get('/analysis')
def analysis_page(): return page('analysis.html')
@bp.get('/accessibility')
def accessibility_page(): return page('accessibility.html')
@bp.get('/scenarios')
def scenarios_page(): return page('scenarios.html')
@bp.get('/reports')
def reports_page(): return page('reports.html')
@bp.get('/help')
def help_page(): return page('help.html')
@bp.get('/verification')
def verification_page(): return page('verification.html')

@bp.get('/api/facilities')
def api_facilities(): return jsonify(success=True, facilities=rows(current_app.config['DATABASE_PATH'],request.args.get('category'),request.args.get('q'),request.args.get('status')))
@bp.get('/api/facilities/<int:fid>')
def api_facility(fid):
    r=get(current_app.config['DATABASE_PATH'],fid)
    return (jsonify(success=True,facility=r) if r else (jsonify(success=False,error='Facility not found.'),404))
@bp.get('/api/categories')
def api_categories(): return jsonify(success=True,categories=categories(current_app.config['DATABASE_PATH']),all_categories=CATEGORIES)


@bp.get('/api/discover/osm')
def api_discover_osm():
    """Discover currently mapped local facilities from OpenStreetMap."""
    try:
        candidates = discover_ilaro()
        return jsonify(success=True, count=len(candidates), candidates=candidates,
                       source="OpenStreetMap / Overpass",
                       note="Candidates are unverified until locally checked.")
    except Exception as e:
        return jsonify(success=False, error=f"OpenStreetMap discovery failed: {e}"), 502


@bp.post('/api/discover/osm/import')
def api_import_osm():
    """Import selected OSM candidates as unverified records."""
    data = request.get_json(silent=True) or {}
    candidates = data.get("candidates") or []
    if not isinstance(candidates, list) or not candidates:
        return jsonify(success=False, error="No facility candidates supplied."), 400
    path = current_app.config['DATABASE_PATH']
    existing = rows(path)
    added, skipped = 0, 0
    imported = []
    from .db import hav
    for candidate in candidates:
        try:
            name = str(candidate.get("name") or "").strip()
            category = str(candidate.get("facility_category") or "Other").strip()
            lat, lon = float(candidate["latitude"]), float(candidate["longitude"])
            if not name or category not in CATEGORIES:
                skipped += 1
                continue
            # Prevent obvious repeated OSM imports without blocking distinct local businesses.
            duplicate = False
            for old in existing:
                if (str(old.get("name") or "").strip().casefold() == name.casefold()
                    and old.get("facility_category") == category):
                    try:
                        if hav(lat, lon, float(old["latitude"]), float(old["longitude"])) <= 0.08:
                            duplicate = True
                            break
                    except Exception:
                        pass
            if duplicate:
                skipped += 1
                continue
            candidate["verification_status"] = "unverified"
            candidate["capture_method"] = "OSM discovery"
            fid = write(path, candidate)
            imported.append(fid)
            existing.append(get(path, fid))
            added += 1
        except Exception:
            skipped += 1
    return jsonify(success=True, added=added, skipped=skipped, ids=imported,
                   note="Imported records remain unverified until field verification.")

@bp.get('/api/summary')
def api_summary(): return jsonify(success=True,summary=summary(current_app.config['DATABASE_PATH']))

@bp.get('/api/verification/summary')
def api_verification_summary():
    path=current_app.config['DATABASE_PATH']
    return jsonify(success=True, summary=verification_summary(path), sources=source_summary(path), localities=locality_summary(path))

@bp.get('/api/verification/facilities')
def api_verification_facilities():
    path=current_app.config['DATABASE_PATH']
    return jsonify(success=True, facilities=rows(path, request.args.get('category'), request.args.get('q'), request.args.get('status')))

@bp.get('/api/verification/<int:fid>')
def api_verification_detail(fid):
    path=current_app.config['DATABASE_PATH']
    facility=get(path,fid)
    if not facility: return jsonify(success=False,error='Facility not found.'),404
    return jsonify(success=True,facility=facility,history=verification_history(path,fid))

@bp.post('/api/verification/<int:fid>/field')
def api_field_verify(fid):
    try:
        facility=mark_field_verified(current_app.config['DATABASE_PATH'],fid,request.get_json(silent=True) or {})
        return jsonify(success=True,facility=facility)
    except Exception as e:
        return jsonify(success=False,error=str(e)),400

@bp.post('/api/verification/<int:fid>/status')
def api_verification_status(fid):
    data=request.get_json(silent=True) or {}
    try:
        facility=update_verification_status(current_app.config['DATABASE_PATH'],fid,data.get('status',''),data)
        return jsonify(success=True,facility=facility)
    except Exception as e:
        return jsonify(success=False,error=str(e)),400

@bp.post('/api/verification/<int:fid>/duplicate')
def api_verification_duplicate(fid):
    data=request.get_json(silent=True) or {}
    try:
        facility=mark_duplicate(current_app.config['DATABASE_PATH'],fid,data.get('duplicate_of'),data.get('verification_notes',''))
        return jsonify(success=True,facility=facility)
    except Exception as e:
        return jsonify(success=False,error=str(e)),400

@bp.get('/api/verification/duplicates')
def api_verification_duplicates():
    try: threshold=float(request.args.get('threshold_km','0.05'))
    except ValueError: threshold=0.05
    return jsonify(success=True,pairs=possible_duplicates(current_app.config['DATABASE_PATH'],threshold))
@bp.get('/api/nearby')
def api_nearby():
    try: lat=float(request.args['lat']); lon=float(request.args['lon']); limit=int(request.args.get('limit',10))
    except Exception: return jsonify(success=False,error='Valid latitude and longitude are required.'),400
    return jsonify(success=True,facilities=nearby(current_app.config['DATABASE_PATH'],lat,lon,request.args.get('category','All'),limit),location={'latitude':lat,'longitude':lon})
@bp.post('/api/facilities')
def api_add():
    d=request.get_json(silent=True) or {}
    try:
        if not d.get('name') or not d.get('facility_category'): raise ValueError('Name and facility category are required.')
        if d.get('facility_category') not in CATEGORIES: raise ValueError('Invalid facility category.')
        lat=float(d['latitude']); lon=float(d['longitude'])
        if not (-90<=lat<=90 and -180<=lon<=180): raise ValueError('Invalid coordinates.')
        d['latitude']=lat; d['longitude']=lon
        if d.get('verification_status') not in VERIFICATION: d['verification_status']='unverified'
        fid=write(current_app.config['DATABASE_PATH'],d)
        return jsonify(success=True,id=fid,facility=get(current_app.config['DATABASE_PATH'],fid))
    except Exception as e: return jsonify(success=False,error=str(e)),400
@bp.put('/api/facilities/<int:fid>')
def api_update(fid):
    if not get(current_app.config['DATABASE_PATH'],fid): return jsonify(success=False,error='Facility not found.'),404
    d=request.get_json(silent=True) or {}
    try:
        d['latitude']=float(d['latitude']); d['longitude']=float(d['longitude']);
        if d.get('facility_category') not in CATEGORIES: raise ValueError('Invalid facility category.')
        if d.get('verification_status') not in VERIFICATION: d['verification_status']='unverified'
        write(current_app.config['DATABASE_PATH'],d,fid); return jsonify(success=True,facility=get(current_app.config['DATABASE_PATH'],fid))
    except Exception as e: return jsonify(success=False,error=str(e)),400
@bp.delete('/api/facilities/<int:fid>')
def api_delete(fid):
    if not get(current_app.config['DATABASE_PATH'],fid): return jsonify(success=False,error='Facility not found.'),404
    delete(current_app.config['DATABASE_PATH'],fid); return jsonify(success=True)
@bp.post('/api/import')
def api_import():
    f=request.files.get('file')
    if not f:return jsonify(success=False,error='Select a CSV file.'),400
    try: added,errors=import_csv(current_app.config['DATABASE_PATH'],f.read().decode('utf-8-sig'))
    except Exception as e:return jsonify(success=False,error=str(e)),400
    return jsonify(success=True,added=added,errors=errors)
@bp.get('/data/facilities_import_template.csv')
def import_template():
    path=os.path.join(current_app.root_path,'..','data','facilities_import_template.csv')
    with open(path,'rb') as f: content=f.read()
    return Response(content,mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=facilities_import_template.csv'})

@bp.get('/api/export/facilities.csv')
def export_csv():
    data=rows(current_app.config['DATABASE_PATH']); out=io.StringIO(); fields=['id','name','facility_type','facility_category','address','phone','description','population_served','latitude','longitude','data_source','verification_status','source_reference','source_date','verification_method','verified_by','verification_date','verification_notes','verification_latitude','verification_longitude','verification_accuracy_m','is_duplicate','duplicate_of','locality','coverage_area','sub_category','ward_or_area','operational_status','opening_hours','website','photo_url','capture_method','created_at','updated_at']; w=csv.DictWriter(out,fieldnames=fields); w.writeheader(); w.writerows(data)
    return Response(out.getvalue(),mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=ilaro_facilities.csv'})
@bp.post('/api/analyze')
def api_analyze(): return jsonify(success=True,results=mcda(current_app.config['DATABASE_PATH'],request.get_json(silent=True) or {}))
@bp.post('/api/accessibility')
def api_accessibility(): return jsonify(success=True,results=accessibility(current_app.config['DATABASE_PATH'],request.get_json(silent=True) or {}))
@bp.post('/api/scenario')
def api_scenario():
    try:return jsonify(success=True,result=scenario(current_app.config['DATABASE_PATH'],request.get_json(silent=True) or {}))
    except Exception as e:return jsonify(success=False,error=str(e)),400
@bp.get('/api/route')
def api_route():
    import json, urllib.request
    try:
        fl=float(request.args['from_lat']); fo=float(request.args['from_lon']); tl=float(request.args['to_lat']); to=float(request.args['to_lon'])
        base=current_app.config['OSRM_BASE_URL'].rstrip('/'); url=f'{base}/route/v1/driving/{fo},{fl};{to},{tl}?overview=full&geometries=geojson'
        with urllib.request.urlopen(url,timeout=8) as f: data=json.load(f)
        if not data.get('routes'): raise ValueError('No route returned.')
        r=data['routes'][0]; return jsonify(success=True,route={'distance_km':round(r['distance']/1000,2),'duration_minutes':round(r['duration']/60,1),'geometry':r['geometry'],'source':'OSRM'})
    except Exception:
        from .db import hav
        try:
            km=hav(fl,fo,tl,to); return jsonify(success=True,route={'distance_km':round(km*1.25,2),'duration_minutes':round(km*1.25/25*60,1),'geometry':None,'source':'estimated'})
        except Exception as e:return jsonify(success=False,error=str(e)),400
@bp.get('/health')
def health(): return jsonify(status='ok',service='GIS-SDSS Ilaro',database=summary(current_app.config['DATABASE_PATH']))
