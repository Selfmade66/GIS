import math
from .db import hav, rows

CENTER=(6.8865,3.0205)
WORKING_BOUNDS=(6.84,6.95,2.94,3.08)

def norm(vals, reverse=False):
    if not vals:return []
    lo=min(vals); hi=max(vals)
    if hi==lo:return [1.0]*len(vals)
    out=[(v-lo)/(hi-lo) for v in vals]
    return [1-x for x in out] if reverse else out

def mcda(path,d):
    lat=float(d.get('latitude') or CENTER[0]); lon=float(d.get('longitude') or CENTER[1])
    w={k:max(0,float(d.get(k,0))) for k in ['accessibility','population','coverage','distance','separation']}
    s=sum(w.values()) or 1
    w={k:v/s for k,v in w.items()}
    fac=rows(path,d.get('category'))
    if not fac:return {"weights":w,"candidates":[],"message":"No mapped facilities are available for the selected category."}
    # Candidate lattice around the Ilaro working area. This is a screening model, not an official land-use boundary.
    cands=[]
    for i in range(7):
        for j in range(7):
            la=WORKING_BOUNDS[0]+i*(WORKING_BOUNDS[1]-WORKING_BOUNDS[0])/6
            lo=WORKING_BOUNDS[2]+j*(WORKING_BOUNDS[3]-WORKING_BOUNDS[2])/6
            ds=[hav(la,lo,r['latitude'],r['longitude']) for r in fac]
            nearest=min(ds); coverage=sum(1 for x in ds if x<=2.0)/len(ds)
            sep=min([hav(la,lo,r['latitude'],r['longitude']) for r in fac] or [0])
            pop=sum(float(r.get('population_served') or 0)/(1+hav(la,lo,r['latitude'],r['longitude'])) for r in fac)
            cands.append({'latitude':round(la,6),'longitude':round(lo,6),'nearest_distance_km':nearest,'coverage':coverage,'population_exposure':pop,'separation_km':sep})
    acc=norm([c['nearest_distance_km'] for c in cands],reverse=True); pop=norm([c['population_exposure'] for c in cands]); cov=[c['coverage'] for c in cands]; sep=norm([c['separation_km'] for c in cands]); dist=norm([c['nearest_distance_km'] for c in cands],reverse=True)
    for i,c in enumerate(cands): c['score']=round(w['accessibility']*acc[i]+w['population']*pop[i]+w['coverage']*cov[i]+w['distance']*dist[i]+w['separation']*sep[i],4)
    cands.sort(key=lambda x:x['score'],reverse=True)
    for i,c in enumerate(cands,1): c['rank']=i
    return {'weights':w,'candidates':cands[:15],'message':'MCDA screening ranks candidate map cells using the configured criteria.'}

def accessibility(path,d):
    fac=rows(path,d.get('category')); radius=float(d.get('radius_km') or 2.0)
    if not fac:return {'grid':[],'underserved':[],'coverage_rate':0,'message':'No facilities are available for this category.'}
    grid=[]
    for i in range(9):
        for j in range(9):
            la=WORKING_BOUNDS[0]+i*(WORKING_BOUNDS[1]-WORKING_BOUNDS[0])/8
            lo=WORKING_BOUNDS[2]+j*(WORKING_BOUNDS[3]-WORKING_BOUNDS[2])/8
            ds=[hav(la,lo,r['latitude'],r['longitude']) for r in fac]; nearest=min(ds)
            status='good' if nearest<=radius else ('moderate' if nearest<=radius*1.75 else 'underserved')
            grid.append({'latitude':round(la,6),'longitude':round(lo,6),'nearest_distance_km':round(nearest,3),'status':status})
    covered=sum(1 for g in grid if g['status']!='underserved')/len(grid)*100
    return {'grid':grid,'underserved':[g for g in grid if g['status']=='underserved'],'coverage_rate':round(covered,1),'radius_km':radius,'message':'Underserved areas are screening cells whose nearest mapped facility exceeds the selected service radius.'}

def scenario(path,d):
    lat=float(d['latitude']); lon=float(d['longitude']); cat=d.get('category') or 'All'
    nearby=[]
    for r in rows(path,cat):
        x=dict(r); x['distance_km']=round(hav(lat,lon,r['latitude'],r['longitude']),3); nearby.append(x)
    nearby.sort(key=lambda x:x['distance_km'])
    nearest=nearby[0] if nearby else None
    return {'candidate':{'latitude':lat,'longitude':lon},'category':cat,'nearest_existing':nearest,'existing_count':len(nearby),'estimated_service_gap_km':round(nearest['distance_km'],3) if nearest else None,'message':'Scenario analysis compares a proposed point with currently mapped facilities; it does not certify land ownership, zoning or legal suitability.'}
