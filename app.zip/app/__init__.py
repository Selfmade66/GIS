import os
from pathlib import Path
from flask import Flask, render_template
from dotenv import load_dotenv
from .db import init_db, ensure_seed_data
from .routes import bp

PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(PROJECT_ROOT / ".env")

def _database_path():
    configured = os.getenv("DATABASE_PATH", "instance/gis_sdss_ilaro.db").strip()
    path = Path(configured)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return str(path.resolve())

def create_app():
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.getenv("SECRET_KEY", "change-this-in-production"),
        DATABASE_PATH=_database_path(),
        OSRM_BASE_URL=os.getenv("OSRM_BASE_URL", "https://router.project-osrm.org"),
        PROJECT_ROOT=str(PROJECT_ROOT),
    )
    init_db(app.config["DATABASE_PATH"])
    ensure_seed_data(app.config["DATABASE_PATH"], PROJECT_ROOT / "data" / "ilaro_facilities_seed.csv")
    app.register_blueprint(bp)
    return app
