import csv
import io
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


# ============================================================
# GIS-SDSS ILARO
# DATABASE / FACILITY DATA ACCESS LAYER
# ============================================================


# Broad Ilaro facility taxonomy.  Categories are intentionally practical so
# small local facilities (not only major institutions) can be captured.
CATEGORIES = [
    "Hospital", "Clinic", "Pharmacy", "Medical Laboratory", "Maternity Centre",
    "Dental Clinic", "Police Station", "Police / Security", "Fire Station",
    "Fire Service", "Hotel", "Guest House", "Lodge", "Short-let / Apartment",
    "Restaurant", "Canteen / Food Vendor", "Fast Food", "Cafe / Coffee Shop",
    "Bakery", "Catering Service", "Market", "Supermarket", "Shopping Mall",
    "Shopping Centre", "Provision Store", "Boutique / Clothing", "Electronics Shop",
    "Phone / Accessories Shop", "Building Materials", "Bank", "ATM",
    "Microfinance Bank", "POS / Agent", "School", "Nursery / Creche",
    "Tutorial / Training Centre", "Computer / ICT Centre", "University / Polytechnic",
    "Government Office", "Post Office", "Court",
    "Library", "Religious Centre", "Church", "Mosque", "Community Centre",
    "Transport", "Bus Stop", "Motor Park", "Filling Station", "Mechanic Workshop",
    "Car Wash", "Vulcanizer / Tyre Service", "Auto Parts", "Laundry",
    "Barbershop / Salon", "Tailor / Fashion", "Printing / Photocopy Centre",
    "PlayStation / Gaming Centre", "Viewing Centre", "Sports / Recreation",
    "Event Centre", "Entertainment Centre", "Hotel / Event Centre",
    "Pharmacy / Drug Shop", "Agro Service", "Public Toilet", "Water Point",
    "Waste / Environmental Service", "Cemetery", "Shopping / Retail", "Other",
]


VERIFICATION = [
    "unverified",
    "mapped",
    "field_verified",
    "verified",
    "needs_review",
    "duplicate",
    "rejected",
]


# ============================================================
# BASE TABLE SCHEMA
#
# IMPORTANT:
# Indexes are NOT created here.
# They are created AFTER migration in init_db().
# This prevents "no such column" errors on older databases.
# ============================================================

SCHEMA = """
CREATE TABLE IF NOT EXISTS facilities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    name TEXT NOT NULL,

    facility_type TEXT NOT NULL
        DEFAULT 'Facility',

    facility_category TEXT NOT NULL
        DEFAULT 'Other',

    address TEXT
        DEFAULT '',

    phone TEXT
        DEFAULT '',

    description TEXT
        DEFAULT '',

    population_served REAL
        DEFAULT 0,

    latitude REAL NOT NULL,

    longitude REAL NOT NULL,

    data_source TEXT
        DEFAULT 'Admin entry',

    verification_status TEXT
        DEFAULT 'unverified',

    source_reference TEXT
        DEFAULT '',

    source_date TEXT
        DEFAULT '',

    verification_method TEXT
        DEFAULT '',

    verified_by TEXT
        DEFAULT '',

    verification_date TEXT
        DEFAULT '',

    verification_notes TEXT
        DEFAULT '',

    verification_latitude REAL,

    verification_longitude REAL,

    verification_accuracy_m REAL,

    is_duplicate INTEGER
        DEFAULT 0,

    duplicate_of INTEGER,

    locality TEXT
        DEFAULT '',

    coverage_area TEXT
        DEFAULT '',

    sub_category TEXT
        DEFAULT '',

    ward_or_area TEXT
        DEFAULT '',

    operational_status TEXT
        DEFAULT 'unknown',

    opening_hours TEXT
        DEFAULT '',

    website TEXT
        DEFAULT '',

    photo_url TEXT
        DEFAULT '',

    capture_method TEXT
        DEFAULT 'Manual entry',

    created_at TEXT NOT NULL,

    updated_at TEXT NOT NULL
);
"""


# ============================================================
# CURRENT UTC TIME
# ============================================================

def utcnow():
    return datetime.now(
        timezone.utc
    ).isoformat(
        timespec="seconds"
    )


def ensure_seed_data(path, seed_path):
    """
    Add missing records from the bundled Ilaro seed CSV without
    overwriting existing administrator edits.
    """
    seed = Path(seed_path)
    if not seed.exists():
        return 0, []

    with connect(path) as c:
        existing = {
            (str(r[0]).strip().casefold(), str(r[1]).strip())
            for r in c.execute(
                "SELECT name, facility_category FROM facilities"
            )
        }

    reader = csv.DictReader(seed.read_text(encoding="utf-8-sig").splitlines())
    missing = []
    for raw in reader:
        key = (
            str(raw.get("name") or "").strip().casefold(),
            str(raw.get("facility_category") or "").strip(),
        )
        if key[0] and key not in existing:
            missing.append(raw)

    if not missing:
        return 0, []

    fields = [
        "name", "facility_type", "facility_category", "address", "phone",
        "description", "population_served", "latitude", "longitude",
        "data_source", "verification_status", "source_reference"
    ]
    payload = io.StringIO()
    writer = csv.DictWriter(payload, fieldnames=fields)
    writer.writeheader()
    for raw in missing:
        writer.writerow({k: raw.get(k, "") for k in fields})

    return import_csv(path, payload.getvalue())


# ============================================================
# DATABASE CONNECTION
# ============================================================

def connect(path):
    """
    Open SQLite database connection.
    """

    p = Path(path)

    p.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    connection = sqlite3.connect(
        p
    )

    connection.row_factory = sqlite3.Row

    return connection


# ============================================================
# DATABASE INITIALISATION / MIGRATION
# ============================================================

def init_db(path):
    """
    Initialise the database and safely migrate older versions.

    Existing records are preserved.
    No demo records are inserted.
    """

    with connect(path) as c:

        # ----------------------------------------------------
        # STEP 1
        # Create the table if it does not already exist.
        #
        # IMPORTANT:
        # No indexes are created at this point.
        # ----------------------------------------------------

        c.executescript(
            SCHEMA
        )

        # ----------------------------------------------------
        # STEP 2
        # Read existing columns.
        # ----------------------------------------------------

        columns = {
            row[1]
            for row in c.execute(
                "PRAGMA table_info(facilities)"
            )
        }

        # ----------------------------------------------------
        # STEP 3
        # Safe migration definitions.
        # ----------------------------------------------------

        additions = {

            "facility_type":
                "TEXT NOT NULL DEFAULT 'Facility'",

            "facility_category":
                "TEXT NOT NULL DEFAULT 'Other'",

            "address":
                "TEXT DEFAULT ''",

            "phone":
                "TEXT DEFAULT ''",

            "description":
                "TEXT DEFAULT ''",

            "population_served":
                "REAL DEFAULT 0",

            "data_source":
                "TEXT DEFAULT 'Admin entry'",

            "verification_status":
                "TEXT DEFAULT 'unverified'",

            "source_reference":
                "TEXT DEFAULT ''",

            "source_date":
                "TEXT DEFAULT ''",

            "verification_method":
                "TEXT DEFAULT ''",

            "verified_by":
                "TEXT DEFAULT ''",

            "verification_date":
                "TEXT DEFAULT ''",

            "verification_notes":
                "TEXT DEFAULT ''",

            "verification_latitude":
                "REAL",

            "verification_longitude":
                "REAL",

            "verification_accuracy_m":
                "REAL",

            "is_duplicate":
                "INTEGER DEFAULT 0",

            "duplicate_of":
                "INTEGER",

            "locality":
                "TEXT DEFAULT ''",

            "coverage_area":
                "TEXT DEFAULT ''",

            "sub_category":
                "TEXT DEFAULT ''",

            "ward_or_area":
                "TEXT DEFAULT ''",

            "operational_status":
                "TEXT DEFAULT 'unknown'",

            "opening_hours":
                "TEXT DEFAULT ''",

            "website":
                "TEXT DEFAULT ''",

            "photo_url":
                "TEXT DEFAULT ''",

            "capture_method":
                "TEXT DEFAULT 'Manual entry'",

            "created_at":
                "TEXT",

            "updated_at":
                "TEXT",
        }

        # ----------------------------------------------------
        # STEP 4
        # Add missing columns.
        # ----------------------------------------------------

        for name, definition in additions.items():

            if name not in columns:

                c.execute(
                    f"""
                    ALTER TABLE facilities
                    ADD COLUMN {name} {definition}
                    """
                )

        # ----------------------------------------------------
        # STEP 5
        # Current columns after migration.
        # ----------------------------------------------------

        columns = {
            row[1]
            for row in c.execute(
                "PRAGMA table_info(facilities)"
            )
        }

        # ----------------------------------------------------
        # STEP 6
        # Normalise existing records.
        # ----------------------------------------------------

        now = utcnow()

        if "created_at" in columns:

            c.execute(
                """
                UPDATE facilities
                SET created_at =
                    COALESCE(
                        created_at,
                        ?
                    )
                """,
                (now,)
            )

        if "updated_at" in columns:

            c.execute(
                """
                UPDATE facilities
                SET updated_at =
                    COALESCE(
                        updated_at,
                        ?
                    )
                """,
                (now,)
            )

        if "facility_type" in columns:

            c.execute(
                """
                UPDATE facilities
                SET facility_type =
                    COALESCE(
                        NULLIF(
                            TRIM(facility_type),
                            ''
                        ),
                        'Facility'
                    )
                """
            )

        if "facility_category" in columns:

            c.execute(
                """
                UPDATE facilities
                SET facility_category =
                    COALESCE(
                        NULLIF(
                            TRIM(facility_category),
                            ''
                        ),
                        'Other'
                    )
                """
            )

        if "verification_status" in columns:

            c.execute(
                """
                UPDATE facilities
                SET verification_status =
                    COALESCE(
                        NULLIF(
                            TRIM(verification_status),
                            ''
                        ),
                        'unverified'
                    )
                """
            )

        if "is_duplicate" in columns:

            c.execute(
                """
                UPDATE facilities
                SET is_duplicate =
                    COALESCE(
                        is_duplicate,
                        0
                    )
                """
            )

        # ----------------------------------------------------
        # STEP 7
        # NOW create indexes.
        #
        # This is the critical fix.
        # All new columns exist before these indexes are created.
        # ----------------------------------------------------

        c.execute(
            """
            CREATE INDEX IF NOT EXISTS
            idx_facilities_category
            ON facilities(facility_category)
            """
        )

        c.execute(
            """
            CREATE INDEX IF NOT EXISTS
            idx_facilities_coords
            ON facilities(latitude, longitude)
            """
        )

        c.execute(
            """
            CREATE INDEX IF NOT EXISTS
            idx_facilities_status
            ON facilities(verification_status)
            """
        )

        c.execute(
            """
            CREATE INDEX IF NOT EXISTS
            idx_facilities_locality
            ON facilities(locality)
            """
        )

        c.execute(
            """
            CREATE INDEX IF NOT EXISTS
            idx_facilities_duplicate
            ON facilities(is_duplicate)
            """
        )

        c.execute(
            """
            CREATE INDEX IF NOT EXISTS
            idx_facilities_source
            ON facilities(data_source)
            """
        )

        # Verification audit trail. Each field-verification or status
        # decision is retained so the dataset remains traceable.
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS verification_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                facility_id INTEGER NOT NULL,
                previous_status TEXT DEFAULT '',
                new_status TEXT NOT NULL,
                verification_method TEXT DEFAULT '',
                verified_by TEXT DEFAULT '',
                verification_date TEXT DEFAULT '',
                latitude REAL,
                longitude REAL,
                accuracy_m REAL,
                notes TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                FOREIGN KEY(facility_id) REFERENCES facilities(id)
            )
            """
        )
        c.execute(
            "CREATE INDEX IF NOT EXISTS idx_verification_history_facility ON verification_history(facility_id)"
        )

        c.commit()


# ============================================================
# FACILITY LISTING
# ============================================================

def rows(
    path,
    category=None,
    q=None,
    status=None
):
    """
    Return facility records.
    """

    with connect(path) as c:

        sql = """
            SELECT *
            FROM facilities
            WHERE 1=1
        """

        parameters = []

        # Category
        if category and category != "All":

            sql += """
                AND facility_category = ?
            """

            parameters.append(
                category
            )

        # Verification status
        if status and status != "All":

            sql += """
                AND verification_status = ?
            """

            parameters.append(
                status
            )

        # Search
        if q:

            sql += """
                AND (
                    name LIKE ?
                    OR address LIKE ?
                    OR facility_type LIKE ?
                    OR locality LIKE ?
                    OR coverage_area LIKE ?
                    OR phone LIKE ?
                )
            """

            like = f"%{q}%"

            parameters.extend(
                [
                    like,
                    like,
                    like,
                    like,
                    like,
                    like,
                ]
            )

        sql += """
            ORDER BY name COLLATE NOCASE
        """

        return [
            dict(row)
            for row in c.execute(
                sql,
                parameters
            )
        ]


# ============================================================
# GET FACILITY
# ============================================================

def get(path, fid):
    """
    Return one facility by ID.
    """

    with connect(path) as c:

        row = c.execute(
            """
            SELECT *
            FROM facilities
            WHERE id = ?
            """,
            (fid,)
        ).fetchone()

        return (
            dict(row)
            if row
            else None
        )


# ============================================================
# WRITE / INSERT / UPDATE
# ============================================================

def write(path, data, fid=None):
    """
    Insert or update a facility record.

    This function supports both the original facility fields and
    the extended field-verification fields.
    """

    now = utcnow()

    fields = [
        "name",
        "facility_type",
        "facility_category",
        "address",
        "phone",
        "description",
        "population_served",
        "latitude",
        "longitude",
        "data_source",
        "verification_status",
        "source_reference",
        "source_date",
        "verification_method",
        "verified_by",
        "verification_date",
        "verification_notes",
        "verification_latitude",
        "verification_longitude",
        "verification_accuracy_m",
        "is_duplicate",
        "duplicate_of",
        "locality",
        "coverage_area",
        "sub_category",
        "ward_or_area",
        "operational_status",
        "opening_hours",
        "website",
        "photo_url",
        "capture_method",
    ]

    data = data or {}

    # ---------------------------------------------------------
    # Prepare values
    # ---------------------------------------------------------

    values = []

    for field in fields:
        values.append(data.get(field, ""))

    # Numeric fields
    try:
        values[6] = float(values[6] or 0)
    except (TypeError, ValueError):
        values[6] = 0.0

    try:
        values[7] = float(values[7])
    except (TypeError, ValueError):
        raise ValueError("Invalid latitude value.")

    try:
        values[8] = float(values[8])
    except (TypeError, ValueError):
        raise ValueError("Invalid longitude value.")

    # Optional verification coordinates
    if values[17] not in ("", None):
        try:
            values[17] = float(values[17])
        except (TypeError, ValueError):
            values[17] = None
    else:
        values[17] = None

    if values[18] not in ("", None):
        try:
            values[18] = float(values[18])
        except (TypeError, ValueError):
            values[18] = None
    else:
        values[18] = None

    # Optional GPS accuracy
    if values[19] not in ("", None):
        try:
            values[19] = float(values[19])
        except (TypeError, ValueError):
            values[19] = None
    else:
        values[19] = None

    # Duplicate flag
    try:
        values[20] = int(values[20] or 0)
    except (TypeError, ValueError):
        values[20] = 0

    # Duplicate reference
    if values[21] in ("", None):
        values[21] = None
    else:
        try:
            values[21] = int(values[21])
        except (TypeError, ValueError):
            values[21] = None

    # ---------------------------------------------------------
    # Normalise values
    # ---------------------------------------------------------

    if not values[0]:
        raise ValueError("Facility name is required.")

    if not values[2]:
        values[2] = "Other"

    if values[2] not in CATEGORIES:
        values[2] = "Other"

    if not values[1]:
        values[1] = "Facility"

    if values[10] not in VERIFICATION:
        values[10] = "unverified"

    # ---------------------------------------------------------
    # UPDATE existing record
    # ---------------------------------------------------------

    if fid:
        assignments = ", ".join(
            f"{field}=?" for field in fields
        )

        sql = f"""
            UPDATE facilities
            SET
                {assignments},
                updated_at=?
            WHERE id=?
        """

        with connect(path) as c:
            c.execute(
                sql,
                (*values, now, fid)
            )
            c.commit()

        return fid

    # ---------------------------------------------------------
    # INSERT new record
    # ---------------------------------------------------------

    columns = ", ".join(fields) + ", created_at, updated_at"

    placeholders = ", ".join(
        ["?"] * (len(fields) + 2)
    )

    sql = f"""
        INSERT INTO facilities (
            {columns}
        )
        VALUES (
            {placeholders}
        )
    """

    with connect(path) as c:
        cur = c.execute(
            sql,
            (*values, now, now)
        )
        c.commit()

        return cur.lastrowid

# ============================================================
# DELETE
# ============================================================

def delete(
    path,
    fid
):
    """
    Delete facility by ID.
    """

    with connect(path) as c:

        c.execute(
            """
            DELETE FROM facilities
            WHERE id = ?
            """,
            (fid,)
        )

        c.commit()


# ============================================================
# HAVERSINE DISTANCE
# ============================================================

def hav(
    lat1,
    lon1,
    lat2,
    lon2
):
    """
    Calculate straight-line distance in kilometres.
    """

    R = 6371.0088

    p1 = math.radians(
        lat1
    )

    p2 = math.radians(
        lat2
    )

    dp = math.radians(
        lat2 - lat1
    )

    dl = math.radians(
        lon2 - lon1
    )

    a = (
        math.sin(dp / 2) ** 2
        +
        math.cos(p1)
        * math.cos(p2)
        * math.sin(dl / 2) ** 2
    )

    return (
        2
        * R
        * math.asin(
            math.sqrt(
                min(
                    1,
                    a
                )
            )
        )
    )


# ============================================================
# DATABASE SUMMARY
# ============================================================

def summary(path):
    """
    Return dashboard summary statistics.
    """

    records = rows(
        path
    )

    total = len(
        records
    )

    mapped_locations = sum(
        1
        for record in records
        if record.get("latitude") is not None
        and record.get("longitude") is not None
    )

    verified = sum(
        1
        for record in records
        if record.get(
            "verification_status"
        )
        in (
            "verified",
            "field_verified",
        )
    )

    category_count = len(
        {
            record.get(
                "facility_category"
            )
            for record in records
            if record.get(
                "facility_category"
            )
        }
    )

    source_count = len(
        {
            record.get(
                "data_source"
            )
            for record in records
            if record.get(
                "data_source"
            )
        }
    )

    population = sum(
        float(
            record.get(
                "population_served"
            )
            or 0
        )
        for record in records
    )

    duplicate_count = sum(
        1
        for record in records
        if int(
            record.get(
                "is_duplicate"
            )
            or 0
        ) == 1
        or record.get(
            "verification_status"
        ) == "duplicate"
    )

    needs_review_count = sum(
        1
        for record in records
        if record.get(
            "verification_status"
        ) == "needs_review"
    )

    unverified_count = sum(
        1
        for record in records
        if record.get(
            "verification_status"
        ) == "unverified"
    )

    mapped_count = sum(
        1
        for record in records
        if record.get(
            "verification_status"
        ) == "mapped"
    )

    field_verified_count = sum(
        1
        for record in records
        if record.get(
            "verification_status"
        ) == "field_verified"
    )

    formally_verified_count = sum(
        1
        for record in records
        if record.get(
            "verification_status"
        ) == "verified"
    )

    return {
        "total_facilities":
            total,

        "mapped_locations":
            mapped_locations,

        "facility_categories":
            category_count,

        "verified_facilities":
            verified,

        "population_served":
            round(
                population,
                1
            ),

        "sources":
            source_count,

        "duplicate_facilities":
            duplicate_count,

        "needs_review":
            needs_review_count,

        "unverified_facilities":
            unverified_count,

        "mapped_facilities":
            mapped_count,

        "field_verified_facilities":
            field_verified_count,

        "formally_verified_facilities":
            formally_verified_count,
    }


# ============================================================
# NEARBY FACILITIES
# ============================================================

def nearby(
    path,
    lat,
    lon,
    category="All",
    limit=10
):
    """
    Return facilities nearest to a coordinate.
    """

    output = []

    for record in rows(
        path,
        category
    ):

        try:

            distance = hav(
                float(lat),
                float(lon),
                float(record["latitude"]),
                float(record["longitude"])
            )

        except (
            TypeError,
            ValueError,
            KeyError
        ):

            continue

        item = dict(
            record
        )

        item[
            "straight_distance_km"
        ] = round(
            distance,
            3
        )

        output.append(
            item
        )

    output.sort(
        key=lambda item:
        item[
            "straight_distance_km"
        ]
    )

    try:

        safe_limit = int(
            limit
        )

    except (
        TypeError,
        ValueError
    ):

        safe_limit = 10

    safe_limit = max(
        1,
        min(
            safe_limit,
            50
        )
    )

    return output[
        :safe_limit
    ]


# ============================================================
# CATEGORIES
# ============================================================

def categories(path):
    """
    Return facility categories currently in the database.
    """

    return sorted(
        {
            record[
                "facility_category"
            ]
            for record in rows(path)
            if record.get(
                "facility_category"
            )
        }
    )


# ============================================================
# VERIFICATION STATUS LIST
# ============================================================

def verification_statuses():
    """
    Return all supported verification statuses.
    """

    return list(
        VERIFICATION
    )


# ============================================================
# VERIFICATION SUMMARY
# ============================================================

def verification_summary(path):
    """
    Return facility counts by verification status.
    """

    records = rows(
        path
    )

    result = {
        status: 0
        for status in VERIFICATION
    }

    for record in records:

        status = record.get(
            "verification_status"
        )

        if status in result:

            result[
                status
            ] += 1

        else:

            result[
                "unverified"
            ] += 1

    return result


# ============================================================
# SOURCE SUMMARY
# ============================================================

def source_summary(path):
    """
    Return facility counts by source.
    """

    records = rows(
        path
    )

    result = {}

    for record in records:

        source = (
            record.get(
                "data_source"
            )
            or "Unknown"
        )

        result[source] = (
            result.get(
                source,
                0
            )
            + 1
        )

    return dict(
        sorted(
            result.items(),
            key=lambda item:
            item[0].lower()
        )
    )


# ============================================================
# LOCALITY SUMMARY
# ============================================================

def locality_summary(path):
    """
    Return facility counts by locality.
    """

    records = rows(
        path
    )

    result = {}

    for record in records:

        locality = (
            record.get(
                "locality"
            )
            or "Unspecified"
        )

        result[locality] = (
            result.get(
                locality,
                0
            )
            + 1
        )

    return dict(
        sorted(
            result.items(),
            key=lambda item:
            item[0].lower()
        )
    )


# ============================================================
# MARK FIELD VERIFIED
# ============================================================

def mark_field_verified(
    path,
    fid,
    verified_by="",
    verification_date="",
    verification_method="Field visit",
    verification_notes="",
    verification_latitude=None,
    verification_longitude=None,
    verification_accuracy_m=None
):
    """
    Mark a facility as field verified.

    Original source coordinates remain unchanged.
    Verification coordinates are stored separately.
    """

    record = get(
        path,
        fid
    )

    if not record:

        raise ValueError(
            "Facility not found."
        )

    if not verification_date:

        verification_date = (
            datetime.now(
                timezone.utc
            )
            .date()
            .isoformat()
        )

    data = dict(
        record
    )

    data[
        "verification_status"
    ] = "field_verified"

    data[
        "verified_by"
    ] = verified_by

    data[
        "verification_date"
    ] = verification_date

    data[
        "verification_method"
    ] = verification_method

    data[
        "verification_notes"
    ] = verification_notes

    if verification_latitude not in (
        None,
        ""
    ):

        data[
            "verification_latitude"
        ] = verification_latitude

    if verification_longitude not in (
        None,
        ""
    ):

        data[
            "verification_longitude"
        ] = verification_longitude

    if verification_accuracy_m not in (
        None,
        ""
    ):

        data[
            "verification_accuracy_m"
        ] = verification_accuracy_m

    return write(
        path,
        data,
        fid=fid
    )


# ============================================================
# MARK FORMALLY VERIFIED
# ============================================================

def mark_verified(
    path,
    fid,
    verified_by="",
    verification_date="",
    verification_method="",
    verification_notes=""
):
    """
    Mark a facility as formally verified.
    """

    record = get(
        path,
        fid
    )

    if not record:

        raise ValueError(
            "Facility not found."
        )

    if not verification_date:

        verification_date = (
            datetime.now(
                timezone.utc
            )
            .date()
            .isoformat()
        )

    data = dict(
        record
    )

    data[
        "verification_status"
    ] = "verified"

    data[
        "verified_by"
    ] = verified_by

    data[
        "verification_date"
    ] = verification_date

    data[
        "verification_method"
    ] = verification_method

    data[
        "verification_notes"
    ] = verification_notes

    return write(
        path,
        data,
        fid=fid
    )


# ============================================================
# MARK NEEDS REVIEW
# ============================================================

def mark_needs_review(
    path,
    fid,
    notes=""
):
    """
    Mark a facility for additional review.
    """

    record = get(
        path,
        fid
    )

    if not record:

        raise ValueError(
            "Facility not found."
        )

    data = dict(
        record
    )

    data[
        "verification_status"
    ] = "needs_review"

    data[
        "verification_notes"
    ] = notes

    return write(
        path,
        data,
        fid=fid
    )


# ============================================================
# MARK DUPLICATE
# ============================================================

def mark_duplicate(
    path,
    fid,
    duplicate_of=None,
    notes=""
):
    """
    Mark a facility as a duplicate.

    The record is NOT automatically deleted.
    """

    record = get(
        path,
        fid
    )

    if not record:

        raise ValueError(
            "Facility not found."
        )

    if duplicate_of:

        target = get(
            path,
            duplicate_of
        )

        if not target:

            raise ValueError(
                "The target duplicate facility does not exist."
            )

        if int(fid) == int(
            duplicate_of
        ):

            raise ValueError(
                "A facility cannot be a duplicate of itself."
            )

    data = dict(
        record
    )

    data[
        "verification_status"
    ] = "duplicate"

    data[
        "is_duplicate"
    ] = 1

    data[
        "duplicate_of"
    ] = duplicate_of

    data[
        "verification_notes"
    ] = notes

    return write(
        path,
        data,
        fid=fid
    )


# ============================================================
# FIND POSSIBLE DUPLICATES
# ============================================================

def possible_duplicates(
    path,
    distance_km=0.05
):
    """
    Find possible duplicate facilities using
    geographic proximity.

    Default radius = 50 metres.
    """

    records = rows(
        path
    )

    candidates = []

    try:

        radius = float(
            distance_km
        )

    except (
        TypeError,
        ValueError
    ):

        radius = 0.05

    for i in range(
        len(records)
    ):

        first = records[i]

        for j in range(
            i + 1,
            len(records)
        ):

            second = records[j]

            try:

                distance = hav(
                    float(
                        first[
                            "latitude"
                        ]
                    ),
                    float(
                        first[
                            "longitude"
                        ]
                    ),
                    float(
                        second[
                            "latitude"
                        ]
                    ),
                    float(
                        second[
                            "longitude"
                        ]
                    )
                )

            except (
                TypeError,
                ValueError,
                KeyError
            ):

                continue

            if distance <= radius:

                first_name = (
                    first.get(
                        "name"
                    )
                    or ""
                ).strip().lower()

                second_name = (
                    second.get(
                        "name"
                    )
                    or ""
                ).strip().lower()

                candidates.append(
                    {
                        "facility_1":
                            first,

                        "facility_2":
                            second,

                        "distance_km":
                            round(
                                distance,
                                4
                            ),

                        "name_match":
                            first_name
                            == second_name,
                    }
                )

    return candidates


# ============================================================
# CSV IMPORT
# ============================================================

def import_csv(
    path,
    content
):
    """
    Import facilities from CSV content.

    Compatible with the existing importer:

        import_csv(filename, content)
    """

    reader = csv.DictReader(
        io.StringIO(
            content
        )
    )

    required = {
        "name",
        "facility_category",
        "latitude",
        "longitude",
    }

    fieldnames = set(
        reader.fieldnames
        or []
    )

    if not required.issubset(
        fieldnames
    ):

        raise ValueError(
            "CSV must contain name, "
            "facility_category, latitude "
            "and longitude columns."
        )

    added = 0

    errors = []

    import_fields = [
        "name",
        "facility_type",
        "facility_category",
        "address",
        "phone",
        "description",
        "population_served",
        "latitude",
        "longitude",
        "data_source",
        "verification_status",
        "source_reference",
        "source_date",
        "verification_method",
        "verified_by",
        "verification_date",
        "verification_notes",
        "verification_latitude",
        "verification_longitude",
        "verification_accuracy_m",
        "is_duplicate",
        "duplicate_of",
        "locality",
        "coverage_area",
        "sub_category",
        "ward_or_area",
        "operational_status",
        "opening_hours",
        "website",
        "photo_url",
        "capture_method",
    ]

    for number, raw in enumerate(
        reader,
        start=2
    ):

        try:

            name = (
                raw.get(
                    "name"
                )
                or ""
            ).strip()

            category = (
                raw.get(
                    "facility_category"
                )
                or ""
            ).strip()

            if not name:

                raise ValueError(
                    "missing name"
                )

            if not category:

                raise ValueError(
                    "missing facility category"
                )

            data = {}

            for field in import_fields:

                value = raw.get(
                    field,
                    ""
                )

                if isinstance(
                    value,
                    str
                ):

                    value = value.strip()

                data[field] = value

            # Default facility type
            if not data[
                "facility_type"
            ]:

                data[
                    "facility_type"
                ] = "Facility"

            # Category
            if (
                data[
                    "facility_category"
                ]
                not in CATEGORIES
            ):

                data[
                    "facility_category"
                ] = "Other"

            # Verification status
            if (
                data[
                    "verification_status"
                ]
                not in VERIFICATION
            ):

                data[
                    "verification_status"
                ] = "unverified"

            # Latitude
            try:

                float(
                    data[
                        "latitude"
                    ]
                )

            except (
                TypeError,
                ValueError
            ):

                raise ValueError(
                    "invalid latitude"
                )

            # Longitude
            try:

                float(
                    data[
                        "longitude"
                    ]
                )

            except (
                TypeError,
                ValueError
            ):

                raise ValueError(
                    "invalid longitude"
                )

            write(
                path,
                data
            )

            added += 1

        except Exception as error:

            errors.append(
                {
                    "row":
                        number,

                    "error":
                        str(error),
                }
            )

    return (
        added,
        errors
    )

# ============================================================
# FIELD VERIFICATION / DATA QUALITY
# ============================================================

def verification_summary(path):
    records = rows(path)
    result = {status: 0 for status in VERIFICATION}
    for record in records:
        status = record.get("verification_status") or "unverified"
        result[status] = result.get(status, 0) + 1
    return result

def source_summary(path):
    with connect(path) as c:
        return [dict(r) for r in c.execute(
            "SELECT COALESCE(NULLIF(data_source,''),'Unspecified') AS source, COUNT(*) AS count FROM facilities GROUP BY source ORDER BY count DESC, source COLLATE NOCASE"
        )]

def locality_summary(path):
    with connect(path) as c:
        return [dict(r) for r in c.execute(
            "SELECT COALESCE(NULLIF(locality,''),'Unspecified') AS locality, COUNT(*) AS count FROM facilities GROUP BY locality ORDER BY count DESC, locality COLLATE NOCASE"
        )]

def _record_history(path, facility_id, previous_status, new_status, data):
    with connect(path) as c:
        c.execute(
            """INSERT INTO verification_history
            (facility_id, previous_status, new_status, verification_method, verified_by, verification_date, latitude, longitude, accuracy_m, notes, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                facility_id, previous_status or "", new_status,
                data.get("verification_method", "") or "",
                data.get("verified_by", "") or "",
                data.get("verification_date", "") or "",
                data.get("verification_latitude"),
                data.get("verification_longitude"),
                data.get("verification_accuracy_m"),
                data.get("verification_notes", "") or "",
                utcnow(),
            )
        )
        c.commit()

def verification_history(path, fid):
    with connect(path) as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM verification_history WHERE facility_id=? ORDER BY id DESC", (fid,)
        )]

def mark_field_verified(path, fid, data):
    facility = get(path, fid)
    if not facility:
        raise ValueError("Facility not found.")
    data = dict(data or {})
    lat = data.get("verification_latitude")
    lon = data.get("verification_longitude")
    if lat in (None, "") or lon in (None, ""):
        raise ValueError("Field verification requires GPS latitude and longitude.")
    try:
        lat, lon = float(lat), float(lon)
    except (TypeError, ValueError):
        raise ValueError("Invalid field GPS coordinates.")
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        raise ValueError("Invalid field GPS coordinates.")
    accuracy = data.get("verification_accuracy_m")
    if accuracy not in (None, ""):
        try: accuracy = float(accuracy)
        except (TypeError, ValueError): accuracy = None
    method = (data.get("verification_method") or "Field GPS").strip()
    verifier = (data.get("verified_by") or "").strip()
    vdate = (data.get("verification_date") or utcnow()[:10]).strip()
    notes = (data.get("verification_notes") or "").strip()
    payload = dict(facility)
    payload.update({
        "verification_status": "field_verified",
        "verification_method": method,
        "verified_by": verifier,
        "verification_date": vdate,
        "verification_notes": notes,
        "verification_latitude": lat,
        "verification_longitude": lon,
        "verification_accuracy_m": accuracy,
    })
    write(path, payload, fid)
    _record_history(path, fid, facility.get("verification_status"), "field_verified", payload)
    return get(path, fid)

def update_verification_status(path, fid, status, data=None):
    if status not in VERIFICATION:
        raise ValueError("Invalid verification status.")
    facility = get(path, fid)
    if not facility:
        raise ValueError("Facility not found.")
    data = dict(data or {})
    payload = dict(facility)
    payload["verification_status"] = status
    for key in ("verification_method", "verified_by", "verification_date", "verification_notes", "verification_latitude", "verification_longitude", "verification_accuracy_m"):
        if key in data:
            payload[key] = data[key]
    if status == "verified" and facility.get("verification_status") not in ("field_verified", "verified"):
        raise ValueError("A facility must be field verified before formal verification.")
    if status == "duplicate":
        payload["is_duplicate"] = 1
    elif status != "duplicate":
        payload["is_duplicate"] = int(payload.get("is_duplicate") or 0)
    write(path, payload, fid)
    _record_history(path, fid, facility.get("verification_status"), status, payload)
    return get(path, fid)

def mark_needs_review(path, fid, notes="", data=None):
    payload = dict(data or {})
    payload["verification_notes"] = notes or payload.get("verification_notes", "")
    return update_verification_status(path, fid, "needs_review", payload)

def mark_duplicate(path, fid, duplicate_of=None, notes=""):
    data = {"verification_notes": notes or "Potential duplicate identified during data-quality review."}
    if duplicate_of not in (None, ""):
        try: duplicate_of = int(duplicate_of)
        except (TypeError, ValueError): duplicate_of = None
    facility = get(path, fid)
    if not facility:
        raise ValueError("Facility not found.")
    payload = dict(facility)
    payload.update(data)
    payload["is_duplicate"] = 1
    payload["duplicate_of"] = duplicate_of
    payload["verification_status"] = "duplicate"
    write(path, payload, fid)
    _record_history(path, fid, facility.get("verification_status"), "duplicate", payload)
    return get(path, fid)

def possible_duplicates(path, threshold_km=0.05):
    records = rows(path)
    pairs = []
    threshold = max(0.001, float(threshold_km))
    for i, a in enumerate(records):
        for b in records[i+1:]:
            try:
                d = hav(float(a["latitude"]), float(a["longitude"]), float(b["latitude"]), float(b["longitude"]))
            except (TypeError, ValueError):
                continue
            if d <= threshold:
                pairs.append({
                    "distance_km": round(d, 4),
                    "facility_a": a,
                    "facility_b": b,
                })
    return sorted(pairs, key=lambda x: x["distance_km"])
